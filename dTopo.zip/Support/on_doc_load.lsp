;; Nalaganje uporabni�kih rutin ob zagonu programa
(load "dTopo.des" "Nekaj je narobe z datoteko dTopo.des")